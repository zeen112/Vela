let fs = require('fs')
let chalk = require('chalk')
let axios = require('axios')

global.owner = ['6281226448082']
global.mods = ['6281226448082'] 
global.prems = ['6281226448082']
global.nameowner = 'Zeen'
global.numberowner = '6281226448082' 
global.mail = 'zeen.1037a@gmail.com' 
global.gc = 'https://chat.whatsapp.com/Itg9iPQubYL8tQUmP3558j'
global.instagram = 'https://instagram.com'
global.wm = `© 2025 \`ＶｅｌａＢｏｔ\``
global.wait = '_*Tunggu, sedang di proses ...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = global.wait
global.packname = 'Hi'
global.author = 'Vela'
global.autobio = false
global.maxwarn = '2'
function pickRandom(array) {
return array[Math.floor(Math.random() * array.length)];
}
global.apikey = 'BotKita'
global.btc = 'Ishowspeed'
global.lann = 'EchaMD'

global.APIs = { 
btc: 'https://api.botcahx.eu.org'
}
global.APIKeys = { 
'https://api.botcahx.eu.org': 'Mark-HDR'
}

global.mess = {
wait: '_*Tunggu, sedang diproses ...*_',
done: `𝖣𝗈𝗇𝖾 ✅\n𝗍𝖾𝗋𝗂𝗆𝖺 𝗄𝖺𝗌𝗂𝗁 𝗍𝖾𝗅𝖺𝗁 𝗆𝖾𝗇𝗀𝗀𝗎𝗇𝖺𝗄𝖺𝗇 𝖤𝖼𝗁𝖺 𝖡𝗈𝗍`,
error: '𝗍𝖾𝗋𝗃𝖺𝖽𝗂 𝗄𝖾𝗌𝖺𝗅𝖺𝗁𝖺𝗇 𝗄𝖾𝗍𝗂𝗄𝖺 𝗆𝖾𝗇𝗃𝖺𝗅𝖺𝗇𝗄𝖺𝗇 𝗉𝖾𝗋𝗂𝗇𝗍𝖺𝗁 𝖺𝗇𝖽𝖺, 𝗌𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝖼𝗈𝖻𝖺 𝗅𝖺𝗀𝗂 𝗇𝖺𝗇𝗍𝗂 𝖺𝗍𝖺𝗎 𝗌𝖾𝗀𝖾𝗋𝖺 𝗁𝗎𝖻𝗎𝗇𝗀𝗂 𝗈𝗐𝗇𝖾𝗋!',
url: '*Link nya mana kak?*'
}

global.payment = {
dana: '0851-7682-7402',
gopay:'0851-7682-7402',
ovo:'0851-7682-7402',
qris: fs.readFileSync(`./src/qris.jpg`)
}

// jgn diubah
let tel = numberowner
global.fkontak = {
	"key": {
"participants":"0@s.whatsapp.net",
		"remoteJid": "status@broadcast",
		"fromMe": false,
		"id": "Halo"
	},
	"message": {
		"contactMessage": {
			"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${tel}:${tel}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
		}
	},
	"participant": "0@s.whatsapp.net"
}

// global function
global.getBuffer = async (url) => {
try {
const response = await axios.get(url, {
responseType: 'arraybuffer',
});
return Buffer.from(response.data);
} catch (error) {
console.error('Error fetching buffer:', error);
throw error;
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log("Update 'config.js'")
delete require.cache[file]
require(file)
})