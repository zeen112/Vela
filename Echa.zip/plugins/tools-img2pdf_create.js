let fs = require("fs");
const { jsPDF } = require("jspdf");
const { loadImage, createCanvas } = require("canvas");

var handler = m => m
handler.before = async function (m, { conn }) {
conn.img2pdf = conn.img2pdf ? conn.img2pdf : {}
const q = m.quoted ? m.quoted : m;
const mime = (q.msg || q).mimetype || q.mediaType || '';
if(m.sender in conn.img2pdf){
let user = m.sender.split('@')[0]
let data = conn.img2pdf[m.sender]
if (/^image/.test(mime) && !/webp/.test(mime)) {
let _now = data.totalHalaman - 1
let now = data.value - _now * 1
if(data.totalHalaman > 1){
await m.reply(`⚪ *IMAGE SAVED*
*• Halaman:* ${now}
*• Status:* Tersimpan

> silahkan kirim *${data.totalHalaman - 1}* gambar lagi untuk menyelesaikan sesi ini
> *Note:* beri jeda minimal 1 detik sebelum mengirimkan gambar baru!`)
let buffer = await q.download()
if (!fs.existsSync(`./src/assets/img2pdf/${user}`)) {
await fs.mkdirSync(`./src/assets/img2pdf/${user}`, { recursive: true });
}
await fs.writeFileSync(`./src/assets/img2pdf/${user}/halaman-${now}.jpg`, buffer)
conn.img2pdf[m.sender].totalHalaman -= 1
} else {
await m.reply(`⚪ *IMAGE SAVED*
*• Halaman:* ${data.value}
*• Status:* Tersimpan

> semua gambar berhasil dikirim, bot sedang memproses perintah anda untuk mengubahnya menjadi file *PDF*
> harap tunggu sebentar ..`)
let buffer = await q.download()
if (!fs.existsSync(`./src/assets/img2pdf/${user}`)) {
await fs.mkdirSync(`./src/assets/img2pdf/${user}`, { recursive: true });
}
await fs.writeFileSync(`./src/assets/img2pdf/${user}/halaman-${now}.jpg`, buffer)
let halaman = data.value
const imagePaths = [];
for (let i = 1; i <= halaman; i++) {
imagePaths.push(`./src/assets/img2pdf/${user}/halaman-${i}.jpg`);
}
await convertImagesToPDF(imagePaths, data.fileName);
let result = await fs.readFileSync(`./tmp/${data.fileName}.pdf`)
await conn.sendMessage(m.chat, {
document: result,
fileName: data.fileName,
mimetype: 'application/pdf'
})
delete conn.img2pdf[m.sender]
}
}
}
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function convertImagesToPDF(imagePaths, title) {
    const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4'
    });

    for (let i = 0; i < imagePaths.length; i++) {
        const img = await loadImage(imagePaths[i]);
        const canvas = createCanvas(img.width, img.height);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);

        const imgData = canvas.toDataURL("image/jpeg");

        const imgWidth = 190;
        const imgHeight = (img.height * imgWidth) / img.width;

        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 10, 10, imgWidth, imgHeight);
    }

    pdf.save(`./tmp/${title}.pdf`);
}

module.exports = handler