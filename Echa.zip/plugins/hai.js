const axios = require("axios");
const sharp = require("sharp");
const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");

// Fungsi untuk mengambil gambar dari URL
let handler = (m, { conn }) => {
async function fetchImage(url) {
    try {
        const response = await axios.get(url, { responseType: "arraybuffer" });
        return Buffer.from(response.data);
    } catch (error) {
        throw new Error(`Gagal mengambil gambar dari URL: ${error.message}`);
    }
}

// Fungsi untuk menyimpan buffer sementara ke file
function saveTemporaryFile(buffer, filename) {
    const tempPath = path.resolve(__dirname, filename);
    fs.writeFileSync(tempPath, buffer);
    return tempPath;
}

// Fungsi untuk menghapus file sementara
function deleteTemporaryFile(filePath) {
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
    }
}

// Fungsi untuk upscale gambar menggunakan Real-ESRGAN
function upscaleWithAI(inputPath, outputPath, scale = 4) {
    return new Promise((resolve, reject) => {
        const realEsrganPath = path.resolve("./remini"); // Path Real-ESRGAN
        const command = `${realEsrganPath} -i "${inputPath}" -o "${outputPath}" -s ${scale}`;
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(`Gagal menjalankan Real-ESRGAN: ${error.message}`);
            }
            if (stderr) {
                console.error("Real-ESRGAN error output:", stderr);
            }
            resolve(outputPath);
        });
    });
}

// Fungsi utama untuk AI upscale dari URL dan output buffer
async function upscaleImageFromUrl(url) {
    const tempInput = "temp-input.jpg";
    const tempOutput = "temp-output.jpg";

    try {
        // Ambil gambar dari URL
        const imageBuffer = await fetchImage(url);

        // Simpan buffer sementara sebagai file input
        const inputPath = saveTemporaryFile(imageBuffer, tempInput);

        // Jalankan Real-ESRGAN untuk upscale
        await upscaleWithAI(inputPath, tempOutput, 4);

        // Ambil hasil gambar sebagai buffer
        const outputBuffer = fs.readFileSync(tempOutput);

        // Hapus file sementara
        deleteTemporaryFile(inputPath);
        deleteTemporaryFile(tempOutput);

        return outputBuffer; // Kembalikan buffer hasil upscale
    } catch (error) {
        console.error("Error:", error.message);
        return null;
    }
}

// Contoh penggunaan
(async () => {
    const imageUrl = "https://i.supa.codes/dJRZt"; // URL gambar
    const resultBuffer = await upscaleImageFromUrl(imageUrl);
    return resultBuffer
    if (resultBuffer) {
        console.log("Gambar berhasil di-upscale, ukuran buffer:", resultBuffer.length);
        // Anda bisa menyimpan buffer atau memproses lebih lanjut
        fs.writeFileSync("output-upscaled.jpg", resultBuffer); // Simpan ke file (opsional)
    }
})();

}

handler.command = ['hai']

module.exports = handler