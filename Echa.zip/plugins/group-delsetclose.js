let handler = async (m, { conn, text, isAdmin }) => {
if(!isAdmin) return global.dfail('admin', m, conn)
    global.db.data.chats[m.chat].sClose = ''
    m.reply(`Sukses mengganti teks *Close* menjadi default`)
}
handler.help = ['delsetclose <teks>']
handler.tags = ['owner', 'group']

handler.command = /^delsetclose$/i
handler.group = true
handler.botAdmin = true

module.exports = handler