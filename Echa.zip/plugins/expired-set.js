let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0] || isNaN(args[0])) throw `Masukkan angka mewakili jumlah hari !\n*Misal : ${usedPrefix + command} 30*`

    let who
    if (m.isGroup) who = args[1] ? args[1] : m.chat
    else who = args[1]

    var jumlahHari = 86400000 * args[0]
    var now = new Date() * 1
    if (now < global.db.data.chats[who].expired) global.db.data.chats[who].expired += jumlahHari
    else global.db.data.chats[who].expired = now + jumlahHari
    await conn.reply(m.chat, `┈ 𝖻𝖾𝗋𝗁𝖺𝗌𝗂𝗅 𝗆𝖾𝗇𝗀𝖺𝗍𝗎𝗋 𝗐𝖺𝗄𝗍𝗎 𝗌𝖾𝗐𝖺 𝗎𝗇𝗍𝗎𝗄 𝗀𝗋𝗎𝗉 𝗂𝗇𝗂, 𝖻𝗈𝗍 𝖺𝗄𝖺𝗇 𝗈𝗍𝗈𝗆𝖺𝗍𝗂𝗌 𝗄𝖾𝗅𝗎𝖺𝗋 𝖺𝗉𝖺𝖻𝗂𝗅𝖺 𝗆𝖺𝗌𝖺 𝗌𝖾𝗐𝖺 𝗌𝗎𝖽𝖺𝗁 𝗁𝖺𝖻𝗂𝗌
🌧️ 𝗁𝗂𝗍𝗎𝗇𝗀 𝗆𝗎𝗇𝖽𝗎𝗋: ${msToDate(global.db.data.chats[who].expired - now)}`, fkontak)
}
handler.help = ['addsewa <hari>']
handler.tags = ['owner']
handler.command = /^(setexpired|addsewa)$/i
handler.owner = true
module.exports = handler

function msToDate(ms) {
    temp = ms
    days = Math.floor(ms / (24 * 60 * 60 * 1000));
    daysms = ms % (24 * 60 * 60 * 1000);
    hours = Math.floor((daysms) / (60 * 60 * 1000));
    hoursms = ms % (60 * 60 * 1000);
    minutes = Math.floor((hoursms) / (60 * 1000));
    minutesms = ms % (60 * 1000);
    sec = Math.floor((minutesms) / (1000));
    return days + " 𝗁𝖺𝗋𝗂 " + hours + " 𝗃𝖺𝗆";
    // +minutes+":"+sec;
}
