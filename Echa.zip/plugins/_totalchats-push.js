let moment = require('moment-timezone')

var handler = m => m
handler.before = async function (m, { text, conn }) {
if(!m.isGroup) return
const isNumber = x => typeof x === 'number' && !isNaN(x)
const _t = new Date(new Date + 3600000);
const tanggal = _t.toLocaleDateString('id', {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
  });
const hari = moment().locale('id').tz("Asia/Jakarta").format("dddd")
let date = `${hari}, ${tanggal}`
let anu = global.db.data.chats[m.chat].totalChats.data
let anu2 = global.db.data.chats[m.chat].totalChats.tanggal
if (typeof anu !== 'object') global.db.data.chats[m.chat].totalChats.data = {}
if (typeof anu2 !== 'object') global.db.data.chats[m.chat].totalChats.tanggal = date
let user = global.db.data.chats[m.chat].totalChats.data[m.sender]
if (typeof user !== 'object') global.db.data.chats[m.chat].totalChats.data[m.sender] = {}
if (user) {
if (!isNumber(user.hit)) user.hit = 0
if (!('name' in user)) user.name = m.pushName
} else global.db.data.chats[m.chat].totalChats.data[m.sender] = {
name: m.pushName,
hit: 0,
}
try {
user.hit += 1
} catch {
console.log(``)
}
}

module.exports = handler