let tiktok = require('../lib/tiktok.js')

let handler = async (m, { conn, args, text, usedPrefix, command }) => { 
 if (!args[0]) throw `🚩 *Example:* ${usedPrefix+command} https://vt.tiktok.com/ZS8TQkpTK/`
await m.react('⏱️')
let anu = await tiktok.tiktokslide(text)
let send
try {
for (let i of anu.image){
send = await conn.sendFile(m.chat, i, '', null, null)
}
await conn.sendMessage(m.chat, {
audio: { url: anu.audio },
mimetype: 'audio/mpeg',
fileName: 'audio.mp3'
},{ quoted: m})
await m.react('✅')
setTimeout(async function(){
await m.react('')
}, 5000)
} catch (e) {
m.reply(`*🚩 Terjadi Kesalahan!*\nError:\n${e.message}`)
}
}
handler.help = ['tiktokslide', 'ttslide'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^(tiktokslide|tiktokimage|ttslide|ttimage|slide)$/i
handler.limit = true

module.exports = handler