var handler = m => m
handler.before = async function (m, { text, conn }) {
conn.PG = conn.PG ? conn.PG : {}
if(m.sender in conn.PG){
let input = m.text.toLowerCase()
if (input.includes('y')){
m.reply('Pesanan Diproses')
delete conn.PG[m.sender]
} else if (input.includes('n')){
m.reply('Pesanan Dibatalkan')
delete conn.PG[m.sender]
}
}
}

module.exports = handler