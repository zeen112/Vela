let handler = async (m, { conn }) => {
let capt = `*Cara melakukan pembayaran*
1. Buka link pembayaran yang dikirimkan penjual 
2. Masukan nominal transaksi
3. pilih metode pembayaran
4. Masukan data yang dibutuhkan pada halaman pembayaran
5. Jika sudah sukses, kirimkan bukti/Screenshoot kepada penjual untuk melanjutkan proses transaksi`
conn.sendFile(m.chat, payment.qris, '', capt, m)
}
handler.help = handler.command = ['pay', 'payment']
handler.tags = ['info']

module.exports = handler