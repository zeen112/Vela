const moment = require('moment-timezone');
let { proto, generateWAMessageFromContent } = require('@adiwajshing/baileys')
const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss');
let tanggal = moment().tz("Asia/Jakarta").locale('id').format("dddd, ll")

const handler = async (m, { conn, usedPrefix, command, groupMetares }) => {
  let anu = db.data.chats[m.chat].listStr;
  let res = Object.keys(anu);
  if (res.length > 0) {
    let grup = await conn.getName(m.key.remoteJid);
    // vip for biwa
    if (["120363379191142931@g.us", "120363345313936997@g.us", "120363309521898971@g.us", "120363289106762107@g.us", "120363299359210223@g.us"].includes(m.chat)) {
    let str = `ㅤㅤㅤㅤ🩰  탕  ׂ  𓈒ㅤ♡   ℬ︀iwa Store   ﹒𓈒  !
ㅤㅤㅤㅤ 𓇼    ۫  ׅ 𓊆 𝗰𝗮𝘁𝗮𝗹𝗼𝗴𝘂𝗲 𝗹𝗶𝘀𝘁 𓊇 ݁ ﹒𓂋
ㅤ   𐚁   ࣪  daftar menu produk biwa store  ..  🧺
ㅤㅤㅤㅤ─────────────────────\n\n`
    let biwa_store = res.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
    let num = 1;
    for (let i of biwa_store) {
      str += `ㅤㅤ♡゙ ִ   ֹֺ  ${i.toLowerCase()}\n`;
    }
    str += `\n𓋜 ╰ ┈ ━━━━━━━━♡━━━━━┈─╸❞ ˶⁠ ֶָ֢  𐚁

 ㅤ “ 𑁯 ׄ  琵琶 𝗻𝗼𝘁𝗲𝗱 ! for all member
> order & transaksi only via pc. pc admin biwa ( wa.me/6281617156243 ) untuk order. *wajib bertanya dahulu, apa yang ingin kalian order ready atau tidak*.  dan pastikan payment yang ingin kalian pakai itu avail atau tidak, wajib konfir ke admin untuk pembayaran, bukan asal tf. all trx noreff & wajib di beli untuk yang lain jika bukan kesalahan admin dan  jika sembarangan tf.`
    await m.reply(str)
    return
    } else if (m.chat == "120363359745157631@g.us") {
    let str = `༊*·˚𝗰𝗮𝗲𝘀𝘇𝘆 𝘀𝘁𝗼𝗿𝗲ᝰ.ᐟ

✮⋆˙𝘭𝘪𝘴𝘵 𝘩𝘦𝘳𝘦 𝘤𝘢𝘦𝘻𝘺ᡣ𐭩.ᐟ

∘₊✧───· · ─ ·𖥸· ─ · ·───✧₊∘\n`
   let cl_store = res.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
    let num = 1;
    for (let i of cl_store) {
      str += `┆۶ৎ ${i.toLowerCase()}\n`;
    }
    str += `╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⇆﹒⎙ *𝐧𝐨𝐭𝐞𝐝* ! for all member
> order & transaksi only via pc. pc admin caezy untuk order. *wajib bertanya dahulu, apa yang ingin kalian order ready atau tidak.* pastikan payment yang ingin kalian pakai itu avail atau tidak, wajib konfir admin untuk pembayaran, bukan asal tf. all trx noreff & wajib dibeli untuk yang lain jika bukan kesalahan admin dan jika sembarangan tf.`
    await m.reply(str)
    return
    }
    let capt = `┈ ⌗𝗁𝖺𝗅𝗅𝗈 @${m.sender.split('@')[0]}
    
    𝗇𝖾𝖾𝖽 𝖺 𝗋𝖾𝗅𝗂𝖺𝖻𝗅𝖾 𝗌𝗁𝗈𝗉𝗉𝗂𝗇𝗀 𝗉𝗅𝖺𝖼𝖾? 𝖨𝗇 ${grup}, 𝖾𝗏𝖾𝗋𝗒𝗍𝗁𝗂𝗇𝗀 𝗒𝗈𝗎 𝖺𝗋𝖾 𝗅𝗈𝗈𝗄𝗂𝗇𝗀 𝖿𝗈𝗋 𝗂𝗌 𝖺𝗏𝖺𝗂𝗅𝖺𝖻𝗅𝖾!
✻ *𝗍𝗂𝗆𝖾* ${jam}

 ╭⊰ ࣪ *𝖼𝖺𝗍𝖺𝗅𝗈𝗀 𝗅𝗂𝗌𝗍* 𑁯❀\n`;
    let firman = res.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
    let num = 1;
    for (let i of firman) {
      capt += ` ┃ 𖢷 ࣪❧ ${i.toLowerCase()}\n`;
    }
    capt += ` ╰┈┈┈⊰ *𝗁𝖺𝗉𝗉𝗒 𝗌𝗁𝗈𝗉𝗂𝗇𝗀* 𑁯❦`
    await conn.reply(m.chat, capt, m)
/*let anu_2 = Object.keys(db.data.chats[m.chat].listStr)
let anu2 = res.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
function toSmall(str) {
  if (str.length === 0) {
    return str;
  }
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}
let list = []
for(let i of anu2){
list.push({ "header": i,
"title": `${i.toLowerCase()}`,
"description": "",
"id": toSmall(i)
})
}
let res2 = JSON.stringify(list, 2, null)
let msgs = generateWAMessageFromContent(m.chat, {
viewOnceMessageV2: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({
text: `${grup}`
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `${jam}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: "𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗽𝗶𝗹𝗶𝗵 𝘀𝗮𝗹𝗮𝗵 𝘀𝗮𝘁𝘂",
subtitle: "",
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": 
`{
title: "Select",
"sections": [
{
"title": "",
"rows": ${res2}
}
]
}`}],})})}}},{})
await conn.relayMessage(m.chat, msgs.message, {
messageId: m.key.id
})*/
  } else {
    m.reply(`Belum ada *list store* di grup ini.`);
  }
}

handler.help = ['store'].map(v => 'list' + v);
handler.tags = ['store', 'group'];
handler.command = /^list(store|shop)?$/i;
handler.group = true;

module.exports = handler;