let handler = async(m, { conn, text }) => {
let chat = db.data.chats[m.chat].listStr
if(Object.keys(chat).includes('PAYMENT')) return

}