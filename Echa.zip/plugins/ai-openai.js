const axios = require('axios');
const util = require("util")
let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*Example:* ${usedPrefix + command} hai ai`;
try {
let request = `"Nama kamu adalah Echa, Tolong Jawab Menggunakan Bahasa Indonesia" Hiraukan bagian ini, jawab pertanyaan setelah tanda sama dengan ( = )
Pertantaan = ${text}`
let anu = await axios.get(`https://loco.web.id/wp-content/uploads/api/v1/bingai.php?q=${encodeURIComponent(request)}`)
await m.reply(anu.data.result.ai_response)
} catch (error) {
m.reply(error.message);
}
};

handler.command = handler.help = ['ai','openai','chatgpt'];
handler.tags = ['tools'];
handler.premium = false
module.exports = handler;