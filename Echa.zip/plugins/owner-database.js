let fs = require('fs')
let moment = require('moment-timezone');

let handler  = async (m, { conn }) => {
let jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
let tanggal = moment().tz("Asia/Jakarta").locale('id').format("dddd, ll")
let capt = `*- ᴅᴀᴛᴀʙᴀsᴇ -*
*⌚ ᴡᴀᴋᴛᴜ:* ${jam}
*📆 ᴛᴀɴɢɢᴀʟ:* ${tanggal}`
let file = fs.readFileSync('./database.json')
conn.sendMessage(m.chat, {
document: file,
mimetype: 'application/json',
fileName: 'database.json',
caption: capt
},{ quoted: fkontak })
}
handler.help = ['getdb','getdatabase']
handler.tags = ['owner']
handler.command = /^(db|getdb)$/i
handler.owner = true

module.exports = handler

let tel = `6283861518933`
let fkontak = {
	"key": {
    "participants":"0@s.whatsapp.net",
		"remoteJid": "status@broadcast",
		"fromMe": false,
		"id": " "
	},
	"message": {
		"contactMessage": {
			"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${tel}:${tel}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
		}
	},
	"participant": "0@s.whatsapp.net"
}