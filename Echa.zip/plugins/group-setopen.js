let handler = async (m, { conn, text, isROwner, isAdmin }) => {
  if (!isAdmin) return global.dfail('admin', m, conn)
  if (text) {
    global.db.data.chats[m.chat].sOpen = text
    m.reply(`Sukses mengganti teks *Open* menjadi:\n\n${text}`)
  } else throw 'Teksnya mana?'
}
handler.help = ['setopen <teks>']
handler.tags = ['owner', 'group']

handler.command = /^setopen$/i
handler.botAdmin = true

module.exports = handler