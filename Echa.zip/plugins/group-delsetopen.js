let handler = async (m, { conn, text, isAdmin }) => {
if(!isAdmin) return global.dfail('admin', m, conn)
    global.db.data.chats[m.chat].sOpen = ''
    m.reply(`Sukses mengganti teks *Open* menjadi default`)
}
handler.help = ['delsetopen <teks>']
handler.tags = ['owner', 'group']

handler.command = /^delsetopen$/i
handler.group = true
handler.botAdmin = true

module.exports = handler