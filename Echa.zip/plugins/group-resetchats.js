const moment = require('moment-timezone');
let handler = async (m, { conn, args, text, usedPrefix, command }) => { 
let grup = await conn.getName(m.key.remoteJid);
let tanggal = moment().tz("Asia/Jakarta").locale('id').format("dddd, ll")
m.reply(`Data chat grup ini telah diperbarui oleh @${m.sender.split('@')[0]}, ketik *${usedPrefix}totalchat* untuk melihatnya\n> *Grup:* ${grup}\n> *Tanggal:* ${tanggal}`)
global.db.data.chats[m.chat].totalChats = {}
}
handler.help = ['resetchats']
handler.tags = ['info']
handler.command = /^(reset(totalcha(t|ts)|cha(t|ts)))$/i
handler.admin = true
handler.group = true

module.exports = handler