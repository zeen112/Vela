let handler = async(m, { conn }) => {
let capt = `1. *Firman Evergarden:* Terima kasih telah menjadi creator dan dev bot yang luar biasa.
2. *Levi Setiadi:* Terima kasih atas bantuan dan kebersamaannya.
3. *Teman-teman dan lainnya:* Terima kasih atas kenangan indah bersama.
4. *Botcahx:* Terima kasih atas kerja sama yang luar biasa.
5. *Betabotz:* Terima kasih atas kolaborasinya.

Semoga kita terus saling mendukung dan berbagi kebahagiaan. Terima kasih atas segala perhatian, cinta, dan kebaikan yang diberikan.`
conn.reply(m.chat, capt, fkontak)
}

handler.help = ['tqto', 'credits']
handler.tags = ['info']
handler.command = ['tqto', 'credits']
module.exports = handler