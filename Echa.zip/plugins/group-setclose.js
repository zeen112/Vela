let handler = async (m, { conn, text, isROwner, isAdmin }) => {
  if (!isAdmin) return global.dfail('admin', m, conn)
  if (text) {
    global.db.data.chats[m.chat].sClose = text
    m.reply(`Sukses mengganti teks *Close* menjadi:\n\n${text}`)
  } else throw 'Teksnya mana?'
}
handler.help = ['setclose <teks>']
handler.tags = ['owner', 'group']

handler.command = /^setclose$/i
handler.botAdmin = true

module.exports = handler