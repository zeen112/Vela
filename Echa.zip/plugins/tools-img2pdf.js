const fs = require("fs");
const { jsPDF } = require("jspdf");
const { loadImage, createCanvas } = require("canvas");

var handler = async (m, { conn, text, command, usedPrefix }) => {
conn.img2pdf = conn.img2pdf ? conn.img2pdf : {}
if(m.sender in conn.img2pdf) return m.reply(`anda masih memiliki room pembuatan pdf yang masih aktif!`)
let warn = `*Format Penggunaan:*\n> ${usedPrefix+command} _Nama Dokumen, Jumlah Halaman_\n\n*Contoh:*\n> ${usedPrefix+command} Presentasi Echa, 12`
if (!text) return m.reply(warn)
let [ fileName, totalHalaman ] = text.split(`,`)
if (!totalHalaman) return m.reply(warn)
await m.reply(`*🟡 CREATE PDF BY ECHA*
*• Pemilik:* @${m.sender.split('@')[0]}
*• Nama Dokumen:* ${fileName}.pdf
*• Total Halaman:* ${totalHalaman}

*TAHAP-TAHAP Pembuatan FILE*
*1.* Silahkan kirim gambar sejumlah *Total Halaman* yang sudah kamu tentukan
*2.* Harap perhatikan urutan gambar yang dikirim karena setelah gambar terkirim file tidak dapar diubah
*3.* Jika jumlah sudah terpenuhi, maka bot akan otomatis mengirimkan file *PDF*
*4.* Apabila anda ingin membatalkan pembuatan file karena alasan _salah ketik judul/salah mengirim halaman/salah menentukan jumlah halaman_ silahkan ketik perintah *${usedPrefix}cancelcreatepdf* dan mulailah dari awal`)
conn.img2pdf[m.sender] = {
fileName: fileName,
totalHalaman: totalHalaman,
value: totalHalaman
}
}

handler.help = handler.command = ['createpdf', 'imgtopdf', 'img2pdf']
handler.tags = ['premium']
handler.premium = true
handler.private = false

module.exports = handler