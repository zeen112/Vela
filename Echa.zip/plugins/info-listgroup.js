let handler = async (m, { conn, participants }) => {

	let now = new Date() * 1
	let groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce).map(v => v[0])
    let txt = ''
    // let tolgp = `${participants.lenght}`
    let num = 1
    for (let [jid, chat] of Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats)) 
    txt += `🌧️ *${num++}.* ${await conn.getName(jid)}\n𝗂𝖽: ${jid.split("@")[0]}\n𝖾𝗑𝗉𝗂𝗋𝖾𝖽: ${db.data.chats[jid].expired ? msToDate(db.data.chats[jid].expired - now) : '*-*'}\n\n`
    m.reply(txt.trim())

}

handler.help = ['grouplist']
handler.tags = ['group']

handler.command = /^(group(s|list)|(s|list)group)$/i


module.exports = handler

function msToDate(ms) {
  temp = ms
  days = Math.floor(ms / (24 * 60 * 60 * 1000));
  daysms = ms % (24 * 60 * 60 * 1000);
  hours = Math.floor((daysms) / (60 * 60 * 1000));
  hoursms = ms % (60 * 60 * 1000);
  minutes = Math.floor((hoursms) / (60 * 1000));
  minutesms = ms % (60 * 1000);
  sec = Math.floor((minutesms) / (1000));
  return days + " 𝗁𝖺𝗋𝗂 " + hours + " 𝗃𝖺𝗆"
  // +minutes+":"+sec;
}