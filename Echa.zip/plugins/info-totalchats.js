let handler = async (m, { conn, args, text, usedPrefix, command }) => { 
let data_a = db.data.chats[m.chat].totalChats
let res = Object.entries(data_a.data)
  .sort(([, a], [, b]) => b.hit - a.hit);
let user = Object.fromEntries(res);
let data = Object.keys(user)
let grup = await conn.getName(m.key.remoteJid);
let capt = `━╾──  *_Total Chat Group_*
» *Jumlah Member Aktif:* ${data.length}
» *Data Dari Tanggal:* ${data_a.tanggal}\n\n`
for(let i of data){
capt += `» @${i.split('@')[0]} *${user[i].hit + 1}* chat\n`
}
m.reply(capt)
}
handler.help = ['totalchats']
handler.tags = ['info']
handler.command = /^(totalcha(t|ts))$/i
handler.admin = true
handler.group = true

module.exports = handler