const { proto } = require('@adiwajshing/baileys');

var handler = async(m, { conn, usedPrefix, command, text }) => {
  let M = proto.WebMessageInfo;
  if (!text || !m.quoted) return m.reply(`Balas pesan dengan perintah *${usedPrefix+command}*\n\n*Contoh :*\n${usedPrefix+command} Payment`);
  let toBig = text.toUpperCase()
  let msgs = db.data.chats[m.chat].listStr;
  if (!(toBig in msgs)) return m.reply(`Tidak ada list dengan bernama *${text}* digrup ini!`);
  
  msgs[toBig] = M.fromObject(await m.getQuotedObj()).toJSON();
  m.reply(`Berhasil mengedit list berjudul *${toBig}* di grup ini^_^\nKetik *${usedPrefix}list* untuk mengeceknya.`);
}

handler.help = ['editlist <text>'];
handler.tags = ['store', 'group', 'adminry'];
handler.command = /^(editlist)$/;
handler.group = true;
handler.admin = true;

module.exports = handler;