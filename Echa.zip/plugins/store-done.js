const moment = require('moment-timezone');

var handler = async (m, { conn, isAdmin }) => {
  const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z');
  const _t = new Date(new Date + 3600000);
  const tanggal = _t.toLocaleDateString('id', {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
  });
  if (!isAdmin) return;
  if (!m.quoted) return;
  let stats = ``;
  if (m.text == 'p' || m.text == 'proses') {
    stats += `📆 ${tanggal}
⏰ ${jam}
--------------------------------------
Hai kak @${m.quoted.sender.split('@')[0]}
Pesanan kamu sedang diproses,
Mohon ditunggu ya!`
  }
  if (m.text == 'd' || m.text == 'done') {
    stats += `📆 ${tanggal}
⏰ ${jam}
--------------------------------------
Hai kak @${m.quoted.sender.split('@')[0]}
Pesanan kamu telah selesai, silahkan di cek ya!
Apabila ada kesalahan segera hubungi admin`
  }
  conn.reply(m.chat, stats, fkontak);
}

handler.customPrefix = /^(done|d|proses|p)$/i;
handler.command = new RegExp();

module.exports = handler;

let tel = `6283861518933`
const fkontak = {
	"key": {
    "participants":"0@s.whatsapp.net",
		"remoteJid": "status@broadcast",
		"fromMe": false,
		"id": " "
	},
	"message": {
		"contactMessage": {
			"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${tel}:${tel}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
		}
	},
	"participant": "0@s.whatsapp.net"
}