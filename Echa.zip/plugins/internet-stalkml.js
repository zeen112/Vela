const axios = require("axios")

var handler = async(m, { conn, args, usedPrefix, command, text }) => {
if(!args[0]) return m.reply(`*🚩 Format:*\n${usedPrefix+command} 𝚒𝚍, 𝚣𝚘𝚗𝚎 𝚒𝚍\n\n*🚩 Example:*\n${usedPrefix+command} 1432691038, 15963`)
let [ id, zoneid ] = text.split(',')
if (!zoneid) return m.reply(`Masukan semua format dengan benar!`)
m.react(`⏱️`)
let anu = await stalkml(id, zoneid)
if ( anu.status === 404 ) {
m.reply(`Tidak dapat menemukan akun dengan ID atau Server yang anda berikan!`)
await m.react(`❌`)
return
}
let capt = `\`- 𝐌𝐨𝐛𝐢𝐥𝐞 𝐋𝐚𝐠𝐞𝐧𝐝𝐬 -\`

> 𝗜𝗗: ${id}
> 𝗭𝗼𝗻𝗲 𝗜𝗗: ${zoneid}
> 𝗡𝗶𝗰𝗸𝗻𝗮𝗺𝗲: ${anu.username}
> 𝗥𝗲𝗴𝗶𝗼𝗻: ${negara(anu.region)}`
await m.reply(capt)
await m.react(`✅`)
}

handler.help = ['stalkml']
handler.command = /^(stalkml|mlstalk|stalkmobilelagend|cekid)$/i
handler.tags = ['internet']

module.exports = handler

async function stalkml(uid, zone){
    try {
        const getPage = await axios.get('https://www.gempaytopup.com/stalk-ml', {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36',
            },
        });

        const csrfToken = getPage.data.match(/name="csrf-token" content="(.*?)"/)?.[1];

        if (!csrfToken) {
            throw new Error('CSRF Token tidak ditemukan!');
        }

        const response = await axios.post(
            'https://www.gempaytopup.com/stalk-ml',
            {
                uid: uid,
                zone: zone,
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'Cookie': getPage.headers['set-cookie'].join('; '),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36',
                },
            }
        );

        return response.data;
    } catch (error) {
        if (error.response) {
            return error.response.data;
        }
        return error.message;
    }
};

function negara(input) {
  const countryCodes = {
    "Afghanistan 🇦🇫": "AF",
    "Albania 🇦🇱": "AL",
    "Algeria 🇩🇿": "DZ",
    "Andorra 🇦🇩": "AD",
    "Angola 🇦🇴": "AO",
    "Antigua and Barbuda 🇦🇬": "AG",
    "Argentina 🇦🇷": "AR",
    "Armenia 🇦🇲": "AM",
    "Australia 🇦🇺": "AU",
    "Austria 🇦🇹": "AT",
    "Azerbaijan 🇦🇿": "AZ",
    "Bahamas 🇧🇸": "BS",
    "Bahrain 🇧🇭": "BH",
    "Bangladesh 🇧🇩": "BD",
    "Barbados 🇧🇧": "BB",
    "Belarus 🇧🇾": "BY",
    "Belgium 🇧🇪": "BE",
    "Belize 🇧🇿": "BZ",
    "Benin 🇧🇯": "BJ",
    "Bhutan 🇧🇹": "BT",
    "Bolivia 🇧🇴": "BO",
    "Bosnia and Herzegovina 🇧🇦": "BA",
    "Botswana 🇧🇼": "BW",
    "Brazil 🇧🇷": "BR",
    "Brunei 🇧🇳": "BN",
    "Bulgaria 🇧🇬": "BG",
    "Burkina Faso 🇧🇫": "BF",
    "Burundi 🇧🇮": "BI",
    "Cambodia 🇰🇭": "KH",
    "Cameroon 🇨🇲": "CM",
    "Canada 🇨🇦": "CA",
    "Cape Verde 🇨🇻": "CV",
    "Central African Republic 🇨🇫": "CF",
    "Chad 🇹🇩": "TD",
    "Chile 🇨🇱": "CL",
    "China 🇨🇳": "CN",
    "Colombia 🇨🇴": "CO",
    "Comoros 🇰🇲": "KM",
    "Congo 🇨🇬": "CG",
    "Congo (DRC) 🇨🇩": "CD",
    "Costa Rica 🇨🇷": "CR",
    "Croatia 🇭🇷": "HR",
    "Cuba 🇨🇺": "CU",
    "Cyprus 🇨🇾": "CY",
    "Czech Republic 🇨🇿": "CZ",
    "Denmark 🇩🇰": "DK",
    "Djibouti 🇩🇯": "DJ",
    "Dominica 🇩🇲": "DM",
    "Dominican Republic 🇩🇴": "DO",
    "Ecuador 🇪🇨": "EC",
    "Egypt 🇪🇬": "EG",
    "El Salvador 🇸🇻": "SV",
    "Equatorial Guinea 🇬🇶": "GQ",
    "Eritrea 🇪🇷": "ER",
    "Estonia 🇪🇪": "EE",
    "Eswatini 🇸🇿": "SZ",
    "Ethiopia 🇪🇹": "ET",
    "Fiji 🇫🇯": "FJ",
    "Finland 🇫🇮": "FI",
    "France 🇫🇷": "FR",
    "Gabon 🇬🇦": "GA",
    "Gambia 🇬🇲": "GM",
    "Georgia 🇬🇪": "GE",
    "Germany 🇩🇪": "DE",
    "Ghana 🇬🇭": "GH",
    "Greece 🇬🇷": "GR",
    "Grenada 🇬🇩": "GD",
    "Guatemala 🇬🇹": "GT",
    "Guinea 🇬🇳": "GN",
    "Guinea-Bissau 🇬🇼": "GW",
    "Guyana 🇬🇾": "GY",
    "Haiti 🇭🇹": "HT",
    "Honduras 🇭🇳": "HN",
    "Hungary 🇭🇺": "HU",
    "Iceland 🇮🇸": "IS",
    "India 🇮🇳": "IN",
    "Indonesia 🇮🇩": "ID",
    "Iran 🇮🇷": "IR",
    "Iraq 🇮🇶": "IQ",
    "Ireland 🇮🇪": "IE",
    "Israel 🇮🇱": "IL",
    "Italy 🇮🇹": "IT",
    "Jamaica 🇯🇲": "JM",
    "Japan 🇯🇵": "JP",
    "Jordan 🇯🇴": "JO",
    "Kazakhstan 🇰🇿": "KZ",
    "Kenya 🇰🇪": "KE",
    "Kiribati 🇰🇮": "KI",
    "Korea (North) 🇰🇵": "KP",
    "Korea (South) 🇰🇷": "KR",
    "Kuwait 🇰🇼": "KW",
    "Kyrgyzstan 🇰🇬": "KG",
    "Laos 🇱🇦": "LA",
    "Latvia 🇱🇻": "LV",
    "Lebanon 🇱🇧": "LB",
    "Lesotho 🇱🇸": "LS",
    "Liberia 🇱🇷": "LR",
    "Libya 🇱🇾": "LY",
    "Liechtenstein 🇱🇮": "LI",
    "Lithuania 🇱🇹": "LT",
    "Luxembourg 🇱🇺": "LU",
    "Madagascar 🇲🇬": "MG",
    "Malawi 🇲🇼": "MW",
    "Malaysia 🇲🇾": "MY",
    "Maldives 🇲🇻": "MV",
    "Mali 🇲🇱": "ML",
    "Malta 🇲🇹": "MT",
    "Marshall Islands 🇲🇭": "MH",
    "Mauritania 🇲🇷": "MR",
    "Mauritius 🇲🇺": "MU",
    "Mexico 🇲🇽": "MX",
    "Micronesia 🇫🇲": "FM",
    "Moldova 🇲🇩": "MD",
    "Monaco 🇲🇨": "MC",
    "Mongolia 🇲🇳": "MN",
    "Montenegro 🇲🇪": "ME",
    "Morocco 🇲🇦": "MA",
    "Mozambique 🇲🇿": "MZ",
    "Myanmar 🇲🇲": "MM",
    "Namibia 🇳🇦": "NA",
    "Nauru 🇳🇷": "NR",
    "Nepal 🇳🇵": "NP",
    "Netherlands 🇳🇱": "NL",
    "New Zealand 🇳🇿": "NZ",
    "Nicaragua 🇳🇮": "NI",
    "Niger 🇳🇪": "NE",
    "Nigeria 🇳🇬": "NG",
    "North Macedonia 🇲🇰": "MK",
    "Norway 🇳🇴": "NO",
    "Oman 🇴🇲": "OM",
    "Pakistan 🇵🇰": "PK",
    "Palau 🇵🇼": "PW",
    "Panama 🇵🇦": "PA",
    "Papua New Guinea 🇵🇬": "PG",
    "Paraguay 🇵🇾": "PY",
    "Peru 🇵🇪": "PE",
    "Philippines 🇵🇭": "PH",
    "Poland 🇵🇱": "PL",
    "Portugal 🇵🇹": "PT",
    "Qatar 🇶🇦": "QA",
    "Romania 🇷🇴": "RO",
    "Russia 🇷🇺": "RU",
    "Rwanda 🇷🇼": "RW",
    "Saint Kitts and Nevis 🇰🇳": "KN",
    "Saint Lucia 🇱🇨": "LC",
    "Saint Vincent and the Grenadines 🇻🇨": "VC",
    "Samoa 🇼🇸": "WS",
    "San Marino 🇸🇲": "SM",
    "Sao Tome and Principe 🇸🇹": "ST",
    "Saudi Arabia 🇸🇦": "SA",
    "Senegal 🇸🇳": "SN",
    "Serbia 🇷🇸": "RS",
    "Seychelles 🇸🇨": "SC",
    "Sierra Leone 🇸🇱": "SL",
    "Singapore 🇸🇬": "SG",
    "Slovakia 🇸🇰": "SK",
    "Slovenia 🇸🇮": "SI",
    "Solomon Islands 🇸🇧": "SB",
    "Somalia 🇸🇴": "SO",
    "South Africa 🇿🇦": "ZA",
    "South Sudan 🇸🇸": "SS",
    "Spain 🇪🇸": "ES",
    "Sri Lanka 🇱🇰": "LK",
    "Sudan 🇸🇩": "SD",
    "Suriname 🇸🇷": "SR",
    "Sweden 🇸🇪": "SE",
    "Switzerland 🇨🇭": "CH",
    "Syria 🇸🇾": "SY",
    "Taiwan 🇹🇼": "TW",
    "Tajikistan 🇹🇯": "TJ",
    "Tanzania 🇹🇿": "TZ",
    "Thailand 🇹🇭": "TH",
    "Timor-Leste 🇹🇱": "TL",
    "Togo 🇹🇬": "TG",
    "Tonga 🇹🇴": "TO",
    "Trinidad and Tobago 🇹🇹": "TT",
    "Tunisia 🇹🇳": "TN",
    "Turkey 🇹🇷": "TR",
    "Turkmenistan 🇹🇲": "TM",
    "Tuvalu 🇹🇻": "TV",
    "Uganda 🇺🇬": "UG",
    "Ukraine 🇺🇦": "UA",
    "United Arab Emirates 🇦🇪": "AE",
    "United Kingdom 🇬🇧": "GB",
    "United States 🇺🇸": "US",
    "Uruguay 🇺🇾": "UY",
    "Uzbekistan 🇺🇿": "UZ",
    "Vanuatu 🇻🇺": "VU",
    "Vatican City 🇻🇦": "VA",
    "Venezuela 🇻🇪": "VE",
    "Vietnam 🇻🇳": "VN",
    "Yemen 🇾🇪": "YE",
    "Zambia 🇿🇲": "ZM",
    "Zimbabwe 🇿🇼": "ZW"
  };

  input = input.toUpperCase();
  for (const [country, code] of Object.entries(countryCodes)) {
    if (country.toUpperCase().includes(input) || code === input) {
      return `${country}`;
    }
  }
  return "Country not found!";
}