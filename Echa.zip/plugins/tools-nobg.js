const fetch = require('node-fetch');
const uploadImage = require('../lib/uploadImage')

let handler = async (m, { conn, usedPrefix, command }) => {
try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (/^image/.test(mime) && !/webp/.test(mime)) {
      const img = await q.download();
      const out = await uploadImage(img);
      await m.reply(wait)

} else {
m.reply(`Kirim/Balas gambar dengan caption *${usedPrefix + command}*`)
}
} catch (e) {
m.reply(`${mess.error}`)
console.log(e)
}
}

handler.command = handler.help = ['nobg', 'removebg'];
handler.tags = ['tools'];
handler.premium = false;
handler.limit = true;

module.exports = handler;