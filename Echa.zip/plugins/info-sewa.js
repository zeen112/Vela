const { getDevice } = require('@adiwajshing/baileys')
let fs = require('fs');

let handler = async(m, { conn, text, usedPrefix, command}) => {
let thum = fs.readFileSync(`./src/sewa.jpg`)
let capt = `𝗁𝖺𝗅𝗅𝗈 @${m.sender.split('@')[0]}
    𝗆𝖾𝗇𝖼𝖺𝗋𝗂 𝖻𝗈𝗍 𝗐𝗁𝖺𝗍𝗌𝖺𝗉𝗉 𝖽𝖾𝗇𝗀𝖺𝗇 𝖻𝖺𝗇𝗒𝖺𝗄 𝖿𝗂𝗍𝗎𝗋 𝗌𝖾𝗋𝖻𝖺𝗀𝗎𝗇𝖺? 𝗌𝖾𝗐𝖺 *Ｖｅｌａ ｂｏｔ* 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗇𝖾𝗆𝖺𝗇𝗂 𝖽𝖺𝗇 𝗆𝖾𝗆𝗎𝖽𝖺𝗁𝗄𝖺𝗇 𝖺𝗄𝗍𝗂𝗏𝗂𝗍𝖺𝗌 𝖽𝗂 𝗀𝗋𝗎𝗉 𝗐𝗁𝖺𝗍𝗌𝖺𝗉𝗉 𝗄𝖺𝗆𝗎!
${readMore}
    *🌧️ 𝖣𝖺𝖿𝗍𝖺𝗋 𝖧𝖺𝗋𝗀𝖺 𝖲𝖾𝗐𝖺 𝖡𝗈𝗍*
┈ ⌗ 15 𝖣𝖺𝗒 𝗃𝗈𝗂𝗇 𝗍𝗁𝖾 𝗀𝗋𝗈𝗎𝗉
𖢷 *price:* 6.000
𖢷 *code:* grup15

┈ ⌗ 30 𝖣𝖺𝗒 𝗃𝗈𝗂𝗇 𝗍𝗁𝖾 𝗀𝗋𝗈𝗎𝗉
𖢷 *price:* 12.000
𖢷 *code:* grup30

┈ ⌗ 60 𝖣𝖺𝗒 𝗃𝗈𝗂𝗇 𝗍𝗁𝖾 𝗀𝗋𝗈𝗎𝗉
𖢷 *price:* 25.000
𖢷 *code:* grup60

    *🌧️ 𝖣𝖺𝖿𝗍𝖺𝗋 𝖧𝖺𝗋𝗀𝖺 𝖴𝗌𝖾𝗋 𝖯𝗋𝖾𝗆𝗂𝗎𝗆*
┈ ⌗ 15 𝖣𝖺𝗒 𝖯𝗋𝖾𝗆𝗂𝗎𝗆
𖢷 *price:* 5.000
𖢷 *code:* prem15

┈ ⌗ 30 𝖣𝖺𝗒 𝖯𝗋𝖾𝗆𝗂𝗎𝗆
𖢷 *price:* 10.000
𖢷 *code:* prem30

┈ ⌗ 60 𝖣𝖺𝗒 𝖯𝗋𝖾𝗆𝗂𝗎𝗆
𖢷 *price:* 20.000
𖢷 *code:* prem60

    *🌧️ 𝖥𝖺𝗌𝗂𝗅𝗂𝗍𝖺𝗌 𝗎𝗌𝖾𝗋 𝗉𝗋𝖾𝗆𝗂𝗎𝗆*
⊹ 𝗍𝗂𝖽𝖺𝗄 𝖺𝖽𝖺 𝖻𝖺𝗍𝖺𝗌𝖺𝗇/𝗅𝗂𝗆𝗂𝗍
⊹ 𝗆𝖾𝗆𝖻𝗎𝗄𝖺 𝖿𝗂𝗍𝗎𝗋 𝗉𝗋𝖾𝗆𝗂𝗎𝗆
⊹ 𝗀𝗋𝖺𝗍𝗂𝗌 𝗋𝖾𝗊𝗎𝖾𝗌𝗍 𝖿𝗂𝗍𝗎𝗋

*𝖼𝖺𝗋𝖺 𝗈𝗋𝖽𝖾𝗋:*
    ${usedPrefix+command} 𝖼𝗈𝖽𝖾
*contoh:*
    ${usedPrefix+command} 𝗀𝗋𝗎𝗉30`
if (!/all/.test(command)){
if (!text) return conn.sendMessage(m.chat, {
image: thum,
caption: capt,
mentions: [m.sender]
},{ quoted: m })
}
let orderID;
switch(text) {
case 'prem15':
orderID = '5.000 IDR';
break;
case 'prem30':
orderID = '10.000 IDR';
break;
case 'prem60':
orderID = '20.000 IDR';
break;
case 'grup15':
orderID = '6.000 IDR';
break;
case 'grup30':
orderID = '12.000 IDR';
break;
case 'grup60':
orderID = '25.000 IDR';
break;
default:
throw `𝗄𝗈𝖽𝖾 𝗅𝖺𝗒𝖺𝗇𝖺𝗇 𝗒𝖺𝗇𝗀 𝖺𝗇𝖽𝖺 𝗆𝖺𝗌𝗎𝗄𝖺𝗇 𝗍𝗂𝖽𝖺𝗄 𝖺𝖽𝖺 𝖽𝗂𝖽𝖺𝖿𝗍𝖺𝗋 𝗁𝖺𝗋𝗀𝖺, 𝗌𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝗆𝖺𝗌𝗎𝗄𝖺𝗇 𝖿𝗈𝗋𝗆𝖺𝗍 𝖽𝖾𝗇𝗀𝖺𝗇 𝖻𝖾𝗇𝖺𝗋!`
};
// Tambahkan variabel untuk link QRIS agar mudah diedit
let qrisLink = 'https://lynk.id/payme/zeen1037'; // Ganti dengan link QRIS Anda

let caption = `*Ｖｅｌａ ｏｒｄｅｒ*\n\n*• Status:* _🟡 Pending_\n*• ID Pembelian:* ${text}\n*• Nominal:* ${orderID}\n*• Payment:*\n\n*TAHAP-TAHAP Pembayaran*\n*1.* Silahkan buka link ini: ${qrisLink}\n*2.* Masukan Nominal: ${orderID}\n*3.* Silahkan Kirim bukti pembayaran ke nomor ini wa.me/${global.numberowner}`

conn.sendMessage(m.sender, { text: caption }, { quoted: m })
conn.reply(m.chat, '✔️ *PESANANMU TELAH DI BUAT*\n\nSaya telah mengirim pembayarannya melalu private chat silahkan di baca dan ikuti tahap-tahap pembayaran. Terimakasih', m)
conn.reply(numberowner + '@s.whatsapp.net', `@${m.sender.split('@')[0]} Sedang dalam pembayaran nominal ${orderID}`, m, { contextInfo: { mentionedJid: [m.sender] }})
}
handler.help = ['grup', 'order']
handler.tags = ['info']
handler.command = ['order', 'sewa']
handler.register = false;
handler.premium = false;

module.exports = handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)