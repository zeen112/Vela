const fetch = require('node-fetch');
let handler = async (m, { conn, args, usedPrefix, command, text }) => {
try {
if (!text) return m.reply(`🚩 𝗅𝗂𝗇𝗄𝗇𝗒𝖺 𝗆𝖺𝗇𝖺 𝗄𝖺𝗄?\n𝖼𝗈𝗇𝗍𝗈𝗁:\n${usedPrefix + command} https://www.facebook.com/reel/493563700392370?mibextid=rS40aB7S9Ucbxw6v`)
m.reply(mess.wait)
let anu = await fetch(`https://api.lolhuman.xyz/api/facebook?apikey=${apikey}&url=${text}`)
if (!anu.ok) return m.reply(mess.error)
let res = await anu.json()
if (res.result.length < 1) return m.reply(mess.error)
conn.sendFile(m.chat, res.result[0], '', mess.done, m)
} catch {
m.reply(mess.error)
}
}
handler.help = ['facebook'].map(v => v + ' <url>');
handler.command = /^(fb|facebook|facebookdl|fbdl|fbdown|dlfb)$/i;
handler.tags = ['downloader'];
handler.limit = true;

module.exports = handler;