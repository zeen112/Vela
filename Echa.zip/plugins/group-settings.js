let { groupsSettingUpdate } = require('@adiwajshing/baileys')
let handler = async (m, { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command }) => {
	if (!(isAdmin || isOwner)) {
		global.dfail('admin', m, conn)
		throw false
	}
	if (!isBotAdmin) {
		global.dfail('botAdmin', m, conn)
		throw false
	}
let chats = db.data.chats[m.chat]
let prefix = usedPrefix
let bu = `Group telah di buka oleh @${m.sender.split`@`[0]} dan sekarang  semua member dapat mengirim pesan
ketik *${usedPrefix}group buka*
Untuk membuka grup!`.trim()            
 	
	if (command == 'close') {
	await conn.groupSettingUpdate(m.chat, 'announcement')
	let teks = `Group telah di tutup oleh @${m.sender.split`@`[0]} dan sekarang hanya admin yang dapat mengirim pesan
ketik *${usedPrefix}group buka*
Untuk membuka grup!`.trim()
    if(chats.sClose.length > 1) teks = chats.sClose
	await m.reply(teks)
	} else if (command == 'open') {
	await conn.groupSettingUpdate(m.chat, 'not_announcement')
	if(chats.sOpen.length > 1) bu = chats.sOpen
	await m.reply(bu)
	}
}

handler.help = ['grup <open/close>']
handler.tags = ['group']
handler.command = /^(open|close)$/i
handler.group = true
handler.botAdmin = false

module.exports = handler