let { youtube } = require('btch-downloader');

let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply(`*Contoh:*\n${usedPrefix + command} https://youtu.be/EN79SfbcvIE?si=ZmSTtpur_jUxYWSE`)
try {
await m.react(`⏱️`)
let anu = await youtube(text)
let capt = `  ◦ *Duration:* ${durasi(anu.duration)}
  ◦ *Author:* ${anu.name}
  ◦ *Description:* ${anu.description}
  ◦ *Views:* ${anu.views}
  ◦ *Wm:* ${wm}
  ◦ *Title:* ${anu.title}`
/*await conn.sendMessage(m.chat, {
video: {
url: `https://ytdl.botwaaa.web.id/yt/dl?url=${text}&type=video`
},
caption: capt
},{ quoted: m })*/
await conn.sendMessage(m.chat, {
image: {
url: anu.image
},
caption: capt
},{ quoted: m })
await conn.sendMessage(m.chat, {
document: {
url: anu.mp3
},
fileName: anu.title,
mimetype: 'audio/mpeg'
},{ quoted: m })
} catch(e){
m.reply(`*Error:*\n${e.message}`)
}
};
handler.help = ['ytmp4', 'yta', 'ytaudio'];
handler.command = /^(ytmp3|yta|ytaudio)$/i
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.private = false;

module.exports = handler;


function durasi(code) {
const match = code.match(/PT(\d+)M(\d+)S/);
if (match) {
let minutes = parseInt(match[1], 10); // Menit
let seconds = parseInt(match[2], 10); // Detik
minutes = minutes.toString().padStart(2, '0');
seconds = seconds.toString().padStart(2, '0');
return `${minutes}:${seconds}`;
}
return "Format tidak valid";
}