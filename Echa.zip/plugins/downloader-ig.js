const { igdl } = require('btch-downloader');
let handler = async (m, { conn, args, usedPrefix, command }) => {
if (!args[0]) throw `*Contoh:* ${usedPrefix}${command} https://www.instagram.com/reel/DCZHWCoS9wY/?igsh=MWN3MHZ6aW9qaDc2dw==`
try {
await m.react('🕒')
const res = await igdl(args[0])
const limitnya = 10; // ini jumlah foto yang ingin di kirim ke user (default 10 foto)
for (let i = 0; i < Math.min(limitnya, res.length); i++) {
await sleep(3000)
await conn.sendFile(m.chat, res[i].url, null, `📥 𝗂𝗇𝗌𝗍𝖺𝗀𝗋𝖺𝗆 𝖽𝗈𝗐𝗇𝗅𝗈𝖺𝖽𝖾𝗋`, m)
m.react('')
}
} catch (e) {
throw mess.error
await m.react('❌')
}
}

handler.help = ['instagram'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^(ig|instagram|igdl|instagramdl|igstroy)$/i
handler.limit = true

module.exports = handler

function sleep(ms) {
return new Promise(resolve => setTimeout(resolve, ms));
}
