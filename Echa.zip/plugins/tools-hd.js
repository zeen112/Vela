const uploadImage = require('../lib/uploadImage')
const axios = require('axios')

let handler = async (m, { conn, usedPrefix, command }) => {
try {
const q = m.quoted ? m.quoted : m;
const mime = (q.msg || q).mimetype || q.mediaType || '';
if (/^image/.test(mime) && !/webp/.test(mime)) {
const img = await q.download();
const out = await uploadImage(img);
m.reply(wait);
if (['hd', 'hd2', 'hd3', 'remini'].includes(command)) {
try {
await m.react('1⃣')
let anu = await getBuffer(`https://lolhuman.xyz/api/upscale?apikey=${apikey}&img=${out}`);
await m.react('2⃣')
let out2 = await uploadImage(anu);
let anu2 = await getBuffer(`https://lolhuman.xyz/api/upscale?apikey=${apikey}&img=${out2}`);
await m.react('✅')
await conn.sendFile(m.chat, anu2, null, wm, m);
} catch {
await m.react('1⃣')
let anu = await getBuffer(`https://lolhuman.xyz/api/upscale?apikey=${apikey}&img=${out}`);
await conn.sendFile(m.chat, anu, null, wm, m);
}
} else if (command === 'removebg' || command === 'nobg') {
let anu = await removeBg(img);
await conn.sendFile(m.chat, anu, null, wm, m);
}
} else {
m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim.`);
}
} catch (e) {
console.error(e.message);
throw e
}
}

handler.command = handler.help = ['hd', 'hd2', 'hd3','removebg','nobg'];
handler.tags = ['tools'];
handler.premium = false;
handler.limit = false;

module.exports = handler;

function pickRandom(arr) {
let randomIndex = Math.floor(Math.random() * arr.length);
return arr[randomIndex];
}

let key_nobg = [
'Z4H8sTxRV4Vwwa31kpNknqHU',
'CYuNtcJdeNsvAcS8hUSjNi85',
'y3mrLkoS49zvgEwEKbqkAV9u',
'pDmvZR76mHLDbpxb938vu712',
'yBBjpBBfawgJTQc8qecWUXvC',
'EAJ3M67G8qWtcZXbFzwNxcRs',
'swUD1ypknELxFLfEX6xLQbSS',
'QCiYJsyn2rhsUx5agSEoUXgW',
'baMWQ1UzaYity3Tci2wfrs89',
'75BVAB5WeQCb9KEYgwvGjpxj'
];

async function removeBg(imageBuffer) {
let response = await axios.post('https://api.remove.bg/v1.0/removebg', imageBuffer, {
headers: {
'X-Api-Key': pickRandom(key_nobg),
'Content-Type': 'application/octet-stream',
},
params: {
size: 'auto',
}
})
if (response.ok) {
return await response.arrayBuffer();
} else {
console.log(`${response.status}: ${response.statusText}`);
}
}