let handler = async (m, { text, usedPrefix, command }) => {
	if (!text) throw `gunakan *${usedPrefix}liststore* untuk melihat daftar pesan yg tersimpan.`;
	let msgs = db.data.chats[m.chat].listStr;
    let input = text.toUpperCase()
	if (!(input in msgs)) throw `*${text.toUpperCase()}* tidak terdaftar di daftar List\n> Ketik ${usedPrefix}list untuk melihat List yang tersedia`;
	delete msgs[input];
	m.reply(`Berhasil menghapus pesan *${text.toUpperCase()}* yang ada di List Store grup ini\n> Data yang telah dihapus tidak dapat dikembalikan`);
}

handler.help = ['list'].map(v => 'del' + v + ' <teks>');
handler.tags = ['store', 'group', 'adminry'];
handler.command = /^dellist$/i;
handler.admin = true;
handler.group = true;

module.exports = handler;