// Import module yang diperlukan
const fs = require('fs');
const path = require('path');

// Fungsi untuk mengirim pesan confess
const sendConfessMessage = async (contact, confession) => {
    try {
        await client.sendMessage(contact.id._serialized, `Menfess:\n\n${confession}`);
    } catch (error) {
        console.error('Gagal mengirim pesan:', error);
    }
};

// Event ketika menerima pesan
client.on('message', async msg => {
    const chat = await msg.getChat();

    // Cek apakah pesan adalah "menfess"
    if (msg.body.startsWith('${prefix}menfess', '${prefix}confess')) {
        const confession = msg.body.slice(9).trim(); // Mengambil isi pesan setelah "!menfess"

        if (confession.length === 0) {
            msg.reply('Format salah! Gunakan: !menfess [pesan]');
            return;
        }

        if (!chat.isGroup) {
            const contact = await msg.getContact();
            const senderId = contact.id._serialized;

            // Baca database untuk memeriksa apakah user adalah premium
            const database = JSON.parse(fs.readFileSync(path.join(__dirname, '../../database.json')));
            const userData = database.users[senderId];
            const isPremium = userData && userData.premium === true;

            if (isPremium) {
                // Pengguna premium, kirim pesan langsung
                await sendConfessMessage(contact, confession);
                msg.reply('Menfess berhasil dikirim!');
            } else {
                // Pengguna gratis, tunda pengiriman 10 detik dan kirim musik
                const delay = 10000; // 10 detik
                
                // Tambahkan variabel untuk link pembayaran agar mudah diedit
                let paymentLink = 'https://lynk.id/payme/zeen1037'; // Ganti dengan link pembayaran Anda
                
                msg.reply(`Pesan menfess Anda akan dikirim dalam ${delay / 1000} detik.\n\nIngin pengiriman instan? Upgrade ke premium di sini:\n${paymentLink}`);

                // Kirim file musik "waiting_musik.mp3" dari folder src
                const musikPath = path.join(__dirname, '../../src', 'waiting_musik.mp3');
                try {
                    await client.sendMessage(contact.id._serialized, {
                        media: fs.createReadStream(musikPath),
                        caption: 'Silakan menunggu...'
                    });
                } catch (error) {
                    console.error('Gagal mengirim musik:', error);
                }

                setTimeout(async () => {
                    await sendConfessMessage(contact, confession);
                    msg.reply('Menfess berhasil dikirim!');
                }, delay);
            }
        } else {
            msg.reply('Perintah hanya bisa digunakan di chat pribadi.');
        }
    }
});