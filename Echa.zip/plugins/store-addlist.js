const { proto } = require('@adiwajshing/baileys');

let handler = async (m, { conn, text, command, usedPrefix }) => {
  let M = proto.WebMessageInfo;
  if (!m.quoted) throw `balas pesan dengan perintah *${usedPrefix + command}*`;
  if (!text) throw `*🚩 Contoh penggunaan:*\n${usedPrefix+command} Test`;
    let msgs = db.data.chats[m.chat].listStr;
  if (text.toUpperCase() in msgs) throw `'${text}' telah terdaftar di List store`;
  
  msgs[text.toUpperCase()] = M.fromObject(await m.getQuotedObj()).toJSON();
  m.reply(`Berhasil menambahkan pesan *${text.toUpperCase()}* ke List Store\n> Akses list dengan cara mengetik namanya`.trim());
}

handler.help = ['list'].map(v => 'add' + v + ' <teks>');
handler.tags = ['store', 'group', 'adminry'];
handler.command = /^addlist$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;