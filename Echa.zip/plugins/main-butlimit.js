var handler = async (m, { conn, usedPrefix }) => {
m.reply(`*L I M I T  A N D A  H A B I S !?*
*B E L I  D O N G*
\`\`\`
100 Limit     › Rp 1.000
200 Limit     › Rp 2.000
350 Limit     › Rp 3.000
500 Limit     › Rp 4.500
700 Limit     › Rp 6.000
1.000 Limit   › Rp 8.000
5.000 Limit   › Rp 15.000
10.000 Limit  › Rp 25.000
20 Limit      › Save Kontak Owner
\`\`\`

> Untuk pembelian silahkan hubungi owner`)
}
handler.command = handler.help = ['buylimit', 'buy']
handler.tags = ['main']

module.exports = handler